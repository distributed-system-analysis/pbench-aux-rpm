#! /bin/sh
export OMP_NUM_THREADS=1
./xlinpack_xeon64 < ./linpack.dat
export OMP_NUM_THREADS=2
./xlinpack_xeon64 < ./linpack.dat
export OMP_NUM_THREADS=4
./xlinpack_xeon64 < ./linpack.dat
export OMP_NUM_THREADS=8
./xlinpack_xeon64 < ./linpack.dat
export OMP_NUM_THREADS=12
./xlinpack_xeon64 < ./linpack.dat
