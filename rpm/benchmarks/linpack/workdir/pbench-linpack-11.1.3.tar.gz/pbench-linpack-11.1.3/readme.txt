This package contains the Intel(R) Optimized LINPACK Benchmark for Linux* OS and
Intel(R) Optimized MP LINPACK Benchmark for Clusters.

Refer to the chapter "LINPACK and MP LINPACK Benchmarks" in the included
MKL User's Guide for information on using these LINPACK benchmarks.

These benchmarks are also included in the full product distributions of:

Intel(R) Math Kernel Library 11.1.3 for Linux* OS

http://www.intel.com/software/products/mkl

* Other names and brands may be claimed as the property of others.
